package com.android.animequo;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class Sign_in extends AppCompatActivity {

    private TextView Sign_in_btn;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_in);
        TextView Sign_in_btn=(TextView)findViewById(R.id.Sign_in_btn);

        Sign_in_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //TODO: Create new Intent :
                Intent i =new Intent(Sign_in.this,Feed.class);
                //TODO: open the Intent :
                startActivity(i);
                //TODO: Animate the Intent :
                overridePendingTransition(R.anim.slide_in_right, R.anim.slide_down);

            }
        });

        Event();


    }
    private void Event()
    {


    }
}

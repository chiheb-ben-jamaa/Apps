package com.android.animequo;


import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import android.widget.TextView;



import org.w3c.dom.Text;

public class Feed extends AppCompatActivity {

    private  static final String LOG="Feed Activity";
    com.airbnb.lottie.LottieAnimationView menu_animate,search_animate;
    private TextView trending,category,bookmark;
    RelativeLayout group_animation_layout;
    boolean visible;

    public   boolean pressed=false;




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_feed);

        menu_animate=(com.airbnb.lottie.LottieAnimationView)findViewById(R.id.menu_animate);
        search_animate=(com.airbnb.lottie.LottieAnimationView)findViewById(R.id.search_animate);



        //trending=(TextView)findViewById(R.id.trending);
        //category=(TextView)findViewById(R.id.category);
        //bookmark=(TextView)findViewById(R.id.bookmark);


        //final RelativeLayout group_animation_layout=(RelativeLayout)findViewById(R.id.group_animation_layout);
        final ViewGroup transitionsContainer = (ViewGroup) findViewById(R.id.transitions_container);





        menu_animate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                //TODO: Play the Animation:
                menu_animate.playAnimation();
                //TODO: Animate Viewhoulder
                visible = !visible;
                if (visible){
                    group_animation_layout.setVisibility(View.INVISIBLE);

                }
                else
                    group_animation_layout.setVisibility(View.VISIBLE);


            }
        });



        search_animate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //TODO: Play the Animation
                search_animate.playAnimation();
                //TODO: Animate the Search Bar:


            }
        });




/*

        trending.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                category.setEnabled(false);
                bookmark.setEnabled(false);
                    if (pressed) {
                        //this for change the icon image from  the defoulat image into read image icon in on click evnet:
                        v.setBackgroundResource(R.drawable.ic_ternding);
                        pressed = true;


                    } else {
                        v.setBackgroundResource(R.drawable.ic_ternding_fill);
                    }


                    pressed = !pressed;
                }


        });






        category.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                trending.setEnabled(false);
                bookmark.setEnabled(false);
                    if (pressed) {
                        //this for change the icon image from  the defoulat image into read image icon in on click evnet:
                        v.setBackgroundResource(R.drawable.ic_category);
                        pressed = true;

                    } else {
                        v.setBackgroundResource(R.drawable.ic_category_fill);
                    }


                    pressed = !pressed;

                }

        });




        bookmark.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                        if (pressed) {
                            //this for change the icon image from  the defoulat image into read image icon in on click evnet:
                            v.setBackgroundResource(R.drawable.ic_bookmark);
                            pressed = true;

                        } else {
                            v.setBackgroundResource(R.drawable.ic_bookmark_fill);
                        }


                        pressed = !pressed;
                    }

        });



*/






        }



}
